// IT Number - IT21318320
// Name - Silva T.U.D
// Group - Y3.S2.SE.WE.0201

package com.sa.safetynet.power.monitor;

public interface PowerMonitor {
	public float calculatePower();
	
	public void generateReport();
}
