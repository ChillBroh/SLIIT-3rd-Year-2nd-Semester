package com.sa.safetynet.accesscontroller.empdetection;

public interface DetectionService {
	
	public boolean checkValidity(String id, String password);
}
