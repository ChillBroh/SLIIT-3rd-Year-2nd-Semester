package com.sa.safetynet.accesscontroller.notificationsystem;

public interface NotificationSystem {
	public void SendNotification(String location);

}
