package com.sa.safetynet.accesscontroller.autodoorsystem;

public interface EmergencyDoorHelper {
	
	public void DoorLockOverride(String command, String location);

}
