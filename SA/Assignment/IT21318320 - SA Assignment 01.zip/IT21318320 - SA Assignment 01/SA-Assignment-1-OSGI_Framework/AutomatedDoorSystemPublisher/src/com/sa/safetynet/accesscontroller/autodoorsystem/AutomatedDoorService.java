package com.sa.safetynet.accesscontroller.autodoorsystem;

public interface AutomatedDoorService {
	public void doorUnlock(String location);
	
	public void doorLock(String location);

}
