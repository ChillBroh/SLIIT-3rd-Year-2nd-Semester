package com.sa.safetynet.alert;

public interface SetAlertInterface {
	public void setEmergAlert(boolean state);
}
