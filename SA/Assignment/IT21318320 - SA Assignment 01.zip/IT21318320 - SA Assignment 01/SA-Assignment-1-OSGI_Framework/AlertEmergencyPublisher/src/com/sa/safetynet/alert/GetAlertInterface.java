package com.sa.safetynet.alert;

public interface GetAlertInterface {
	public boolean getEmergState();
}
